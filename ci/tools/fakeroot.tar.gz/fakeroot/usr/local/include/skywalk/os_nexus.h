/*
 * Copyright (c) 2015-2022 Apple Inc. All rights reserved.
 *
 * @APPLE_OSREFERENCE_LICENSE_HEADER_START@
 *
 * This file contains Original Code and/or Modifications of Original Code
 * as defined in and that are subject to the Apple Public Source License
 * Version 2.0 (the 'License'). You may not use this file except in
 * compliance with the License. The rights granted to you under the License
 * may not be used to create, or enable the creation or redistribution of,
 * unlawful or unlicensed copies of an Apple operating system, or to
 * circumvent, violate, or enable the circumvention or violation of, any
 * terms of an Apple operating system software license agreement.
 *
 * Please obtain a copy of the License at
 * http://www.opensource.apple.com/apsl/ and read it before using this file.
 *
 * The Original Code and all software distributed under the License are
 * distributed on an 'AS IS' basis, WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESS OR IMPLIED, AND APPLE HEREBY DISCLAIMS ALL SUCH WARRANTIES,
 * INCLUDING WITHOUT LIMITATION, ANY WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, QUIET ENJOYMENT OR NON-INFRINGEMENT.
 * Please see the License for the specific language governing rights and
 * limitations under the License.
 *
 * @APPLE_OSREFERENCE_LICENSE_HEADER_END@
 */

#ifndef _SKYWALK_OS_NEXUS_H_
#define _SKYWALK_OS_NEXUS_H_


#include <stdint.h>
#include <sys/types.h>
#include <sys/cdefs.h>
#include <uuid/uuid.h>
#include <mach/boolean.h>


struct ifnet_traffic_descriptor_common;
struct ifnet_traffic_rule_action;

/*
 * Nexus terminology and overview.  The relationship between the objects are
 * as follows:
 *
 *	domain --> domain_provider --> nexus_provider --> nexus
 *
 * Skywalk comes with several nexus domains (types).  Each domain has one or
 * more domain providers; the system comes with a built-in (default) domain
 * provider per domain.  Additional domain providers may be attached, but
 * this ability is reserved to kernel subsystems.  The domain specifies the
 * nexus semantics, including the permitted topology, number and definition
 * of ports, memory regions, etc.
 *
 * Each domain provider may have one or more nexus providers registered to it.
 * This allows different parameters (rings, slots, buffer metadata) to be
 * configured on a per-nexus provider basis.
 *
 * Nexus instances can then be allocated based on a registered nexus provider.
 * All instances associated with a given nexus provider share the same set of
 * parameters that are configured for that nexus provider.
 *
 * Channels are then opened to nexus instances.
 */

/*
 * Nexus types.
 *
 * Userland code may only register Nexus providers against the USER_PIPE
 * and FLOW_SWITCH types.  The rest are reserved for kernel subsystems.
 */
typedef enum {
	NEXUS_TYPE_USER_PIPE,           /* pipe (user) */
	NEXUS_TYPE_KERNEL_PIPE,         /* pipe (kernel) */
	NEXUS_TYPE_NET_IF,              /* network interface (kernel) */
	NEXUS_TYPE_FLOW_SWITCH,         /* flow switch (user/kernel) */
} nexus_type_t;

/*
 * Nexus provider name.
 */
typedef uint8_t nexus_name_t[64];

/*
 * Nexus instance port.
 */
typedef uint16_t nexus_port_t;

/*
 * User pipe Nexus has at most two ports: one client and server.
 */
#define NEXUS_PORT_USER_PIPE_CLIENT             0
#define NEXUS_PORT_USER_PIPE_SERVER             1

/*
 * Kernel pipe Nexus has at most one port for the client.
 */
#define NEXUS_PORT_KERNEL_PIPE_CLIENT           0

/*
 * Network Interface Nexus can have any number of ports.
 * Port 0 and 1 are reserved for DEV and HOST. The other ports
 * (2 and above) can be of the types: filter, custom ethertype,
 * or low latency.
 */
#define NEXUS_PORT_NET_IF_DEV                   0
#define NEXUS_PORT_NET_IF_HOST                  1
#define NEXUS_PORT_NET_IF_CLIENT                2

/*
 * Flow switch has its first N ports reserved; the following is the first
 * client usable port.  The last usable depends on the configured number
 * of nexus ports.
 */
#define NEXUS_PORT_FLOW_SWITCH_CLIENT           2

/*
 * Opaque handles.
 */
struct nexus_controller;
struct nexus_attr;

typedef struct nexus_controller         *nexus_controller_t;
typedef struct nexus_attr               *nexus_attr_t;

/*
 * Nexus attribute types.
 */
typedef enum {
	NEXUS_ATTR_TX_RINGS,            /* (g/s) # of transmit rings */
	NEXUS_ATTR_RX_RINGS,            /* (g/s) # of receive rings */
	NEXUS_ATTR_TX_SLOTS,            /* (g/s) # of slots per transmit ring */
	NEXUS_ATTR_RX_SLOTS,            /* (g/s) # of slots per receive ring */
	NEXUS_ATTR_SLOT_BUF_SIZE,       /* (g/s) buffer per slot (bytes) */
	NEXUS_ATTR_SLOT_META_SIZE,      /* (g) metadata per slot (bytes) */
	NEXUS_ATTR_ANONYMOUS,           /* (g/s) allow anonymous clients */
	NEXUS_ATTR_MHINTS,              /* (g/s) memory usage hints */
	NEXUS_ATTR_PIPES,               /* (g/s) # of pipes */
	NEXUS_ATTR_EXTENSIONS,          /* (g/s) extension-specific attr */
	NEXUS_ATTR_IFINDEX,             /* (g) network interface index */
	NEXUS_ATTR_STATS_SIZE,          /* (g) statistics region size (bytes) */
	NEXUS_ATTR_FLOWADV_MAX,         /* (g) max flow advisory entries */
	NEXUS_ATTR_QMAP,                /* (g/s) queue mapping type */
	NEXUS_ATTR_CHECKSUM_OFFLOAD,    /* (g) partial checksum offload */
	NEXUS_ATTR_USER_PACKET_POOL,    /* (g) user packet pool */
	NEXUS_ATTR_ADV_SIZE,            /* (g) nexus advisory region size */
	NEXUS_ATTR_USER_CHANNEL,        /* (g/s) allow user channel open */
	NEXUS_ATTR_MAX_FRAGS,           /* (g/s) max fragments in a packets */
	/*
	 * (g/s) reject channel operations on nexus if the peer has closed
	 * the channel.
	 * The os channel will appear as defunct to the active peer.
	 */
	NEXUS_ATTR_REJECT_ON_CLOSE,
	NEXUS_ATTR_LARGE_BUF_SIZE,     /* (g/s) size of large buffer (bytes) */
} nexus_attr_type_t;

/*
 * XXX: this is temporary and should be removed later.
 */
#define OS_NEXUS_HAS_USER_PACKET_POOL           1

/*
 * Memory usage hint attributes that can be specified for NEXUS_ATTR_MHINTS
 * These can be OR'ed to specified multiple hints
 */
/* No hint, default behaviour */
#define NEXUS_MHINTS_NORMAL     0x0
/* Application expects to access the channels soon */
#define NEXUS_MHINTS_WILLNEED   0x1
/* Application expects low latency for bursty traffic */
#define NEXUS_MHINTS_LOWLATENCY 0x2
/* Application expects high usage of channel memory */
#define NEXUS_MHINTS_HIUSE      0x4

/*
 * Extension attributes.
 */
typedef enum {
	NEXUS_EXTENSION_TYPE_MAXTYPE = 0,
} nexus_extension_t;

/*
 * Nexus queue mapping types.
 */
typedef enum {
	NEXUS_QMAP_TYPE_INVALID = 0,    /* invalid type */
	NEXUS_QMAP_TYPE_DEFAULT,        /* 10:1 mapping */
	NEXUS_QMAP_TYPE_WMM,            /* 802.11 WMM */
} nexus_qmap_type_t;

#define NEXUS_NUM_WMM_QUEUES    4       /* number of WMM access categories */

/*
 * Nexus buffer metadata template.
 *
 * Each Nexus provider implementation will define an overlay of this structure;
 * the top of the structure always begins with this common area.  The contents
 * of this common area, as well as the rest of the per-buffer metadata region
 * are left to the provider to define.
 *
 * This structure is aligned for efficient copy and accesses.
 */
typedef struct nexus_mdata {
	union {
		uuid_t          __uuid;         /* flow UUID */
		uint8_t         __val8[16];
		uint16_t        __val16[8];
		uint32_t        __val32[4];
		uint64_t        __val64[2];
	} __flowid_u;
#define nm_flowid_uuid  __flowid_u.__uuid
#define nm_flowid_val8  __flowid_u.__val8
#define nm_flowid_val16 __flowid_u.__val16
#define nm_flowid_val32 __flowid_u.__val32
#define nm_flowid_val64 __flowid_u.__val64
} nexus_mdata_t __attribute((aligned(8)));

/*
 * Nexus bind flags.
 */
#define NEXUS_BIND_PID          0x1     /* bind to a process ID */
#define NEXUS_BIND_EXEC_UUID    0x2     /* bind to a process exec's UUID */
#define NEXUS_BIND_KEY          0x4     /* bind to a key blob */

/*
 * Maximum length of key blob (in bytes).
 */
#define NEXUS_MAX_KEY_LEN       1024

/*
 * User APIs.
 */
#if !defined(_POSIX_C_SOURCE) || defined(_DARWIN_C_SOURCE)
__BEGIN_DECLS
/*
 * Creates a Nexus attribute object.
 *
 * This must be paired with a os_nexus_attr_destroy() on the handle.
 */
extern nexus_attr_t os_nexus_attr_create(void);

/*
 * Clones a Nexus attribute object.  If source attribute is NULL
 * it behaves just like os_nexus_attr_create();
 *
 * This must be paired with a os_nexus_attr_destroy() on the handle.
 */
extern nexus_attr_t os_nexus_attr_clone(const nexus_attr_t attr);

/*
 * Sets a value for a given attribute type on a Nexus attribute object.
 */
extern int os_nexus_attr_set(nexus_attr_t attr,
    const nexus_attr_type_t type, const uint64_t value);

/*
 * Gets a value for a given attribute type on a Nexus attribute object.
 */
extern int os_nexus_attr_get(const nexus_attr_t attr,
    const nexus_attr_type_t type, uint64_t *value);

/*
 * Destroys a Nexus attribute object.
 */
extern void os_nexus_attr_destroy(nexus_attr_t attr);

/*
 * Opens a handle to the Nexus controller.
 *
 * This must be paired with a os_nexus_controller_destroy() on the handle, in
 * order to remove any remaining active providers and free resources.
 */
extern nexus_controller_t os_nexus_controller_create(void);

/*
 * Retrieves the file descriptor associated with the Nexus controller.
 */
extern int os_nexus_controller_get_fd(const nexus_controller_t ctl);

/*
 * Registers a Nexus provider.
 *
 * Anonymous Nexus provider mode implies the freedom to connect to the Nexus
 * instance from any channel client.  Alternatively, named mode requires the
 * Nexus provider to explicitly bind a Nexus instance port to a set of client
 * attributes.  This mode (named) is the default behavior, and is done so to
 * encourage Nexus providers to explicitly know about the clients that it's
 * communicating with.  Specifying anonymous mode can be done via the Nexus
 * attribute NEXUS_ATTR_ANONYMOUS, by setting it to a non-zero value.
 *
 * The client binding attributes include the process ID, the executable UUID,
 * and/or a key blob.  Only a client possessing those will be allowed to open
 * a channel to the Nexus instance port.
 */
extern int os_nexus_controller_register_provider(const nexus_controller_t ctl,
    const nexus_name_t name, const nexus_type_t type, const nexus_attr_t attr,
    uuid_t *prov_uuid);

/*
 * Deregisters a Nexus provider.
 */
extern int os_nexus_controller_deregister_provider(const nexus_controller_t ctl,
    const uuid_t prov_uuid);

/*
 * Creates a Nexus instance of a registered provider.
 */
extern int os_nexus_controller_alloc_provider_instance(
	const nexus_controller_t ctl, const uuid_t prov_uuid, uuid_t *nx_uuid);

/*
 * Destroys a Nexus instance.
 */
extern int os_nexus_controller_free_provider_instance(
	const nexus_controller_t ctl, const uuid_t nx_uuid);

/*
 * Bind a port of a Nexus instance to one or more attributes associated with
 * a channel client: process ID, process executable's UUID, or key blob.
 * This is only applicable to named Nexus provider.
 *
 * Binding to a process ID implies allowing only a channel client with such
 * PID to open the Nexus port.
 *
 * Binding to an executable UUID allows a channel client (regardless of PID
 * or instance) with such executable UUID to open the Nexus port.  When this
 * is requested by a provider that doesn't have the client's executable UUID,
 * a valid client PID must be provided (with the executable UUID zeroed out)
 * in order for the kernel to retrieve the executable UUID from the process
 * and to use that as the bind attribute.  Else, a non-zero executable UUID
 * can be specified (PID is ignored in this case) by the provider.
 *
 * Binding to a key blob allows a channel client possessing the identical
 * key blob to open the Nexus port.  The key blob is opaque to the system,
 * and is left to the Nexus provider to interpret and relay to its client.
 *
 * A Nexus provider must choose to select one or a combination of those
 * attributes for securing access to a port of a named Nexus instance.
 * The provider is also responsible for detecting if the client has gone
 * away, and either to unbind the Nexus instance port indefinitely, or
 * reissue another bind with the new client binding attributes for that
 * same port.  This is to handle cases where the client terminates and
 * is expected to reattach to the same port.
 *
 * All port bindings belonging to a Nexus instance will be automatically
 * removed when the Nexus instance is destroyed.
 */
extern int os_nexus_controller_bind_provider_instance(
	const nexus_controller_t ctl, const uuid_t nx_uuid, const nexus_port_t port,
	const pid_t pid, const uuid_t exec_uuid, const void *key,
	const uint32_t key_len, const uint32_t bind_flags);

/*
 * Unbind a previously-bound port of a Nexus instance.  This is only
 * applicable to named Nexus provider.  A previously-bound Nexus instance
 * port cannot be bound again until this call is issued.
 */
extern int os_nexus_controller_unbind_provider_instance(
	const nexus_controller_t ctl, const uuid_t nx_uuid,
	const nexus_port_t port);

/*
 * Retrieves current Nexus provider attributes into the nexus_attr_t handle.
 */
extern int os_nexus_controller_read_provider_attr(const nexus_controller_t ctl,
    const uuid_t prov_uuid, nexus_attr_t attr);

/*
 * Traffic rules APIs.
 */

/* Persist after controller close. */
#define NXCTL_ADD_TRAFFIC_RULE_FLAG_PERSIST 0x0001
extern int os_nexus_controller_add_traffic_rule(const nexus_controller_t ctl,
    const char *ifname, const struct ifnet_traffic_descriptor_common *td,
    const struct ifnet_traffic_rule_action *ra, const uint32_t flags,
    uuid_t *rule_uuid);

extern int os_nexus_controller_remove_traffic_rule(const nexus_controller_t ctl,
    const uuid_t rule_uuid);

struct nexus_traffic_rule_info {
	uuid_t *nri_rule_uuid;
	char *nri_owner;
	char *nri_ifname;
	struct ifnet_traffic_descriptor_common *nri_td;
	struct ifnet_traffic_rule_action *nri_ra;
	uint32_t nri_flags;
};
/* Return TRUE to continue, FALSE to exit. */
typedef boolean_t (nexus_traffic_rule_iterator_t)(void *,
    const struct nexus_traffic_rule_info *);

extern int os_nexus_controller_iterate_traffic_rules(const nexus_controller_t ctl,
    nexus_traffic_rule_iterator_t itr, void *itr_arg);

/*
 * Destroys a Nexus controller handle.
 */
extern void os_nexus_controller_destroy(nexus_controller_t ctl);
__END_DECLS
#endif  /* (!_POSIX_C_SOURCE || _DARWIN_C_SOURCE) */
#endif /* !_SKYWALK_OS_NEXUS_H_ */
